package main

import "testshared/dep3"

func main() {
	dep3.D3()
}
